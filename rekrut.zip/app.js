// INITIAL DATA (Mocking Database)
let jobs = [
    { id: 1, title: 'Frontend Developer', dept: 'Engineering', status: 'Active', applicants: 3 },
    { id: 2, title: 'UI/UX Designer', dept: 'Design', status: 'Active', applicants: 1 },
    { id: 3, title: 'Product Manager', dept: 'Product', status: 'Closed', applicants: 1 }
];

let candidates = [
    { id: 101, name: 'Budi Santoso', email: 'budi@example.com', jobTitle: 'Frontend Developer', stage: 'Applied' },
    { id: 102, name: 'Siti Aminah', email: 'siti@example.com', jobTitle: 'Frontend Developer', stage: 'Interview' },
    { id: 103, name: 'Rian Wijaya', email: 'rian@example.com', jobTitle: 'UI/UX Designer', stage: 'Interview' },
    { id: 104, name: 'Dewi Lestari', email: 'dewi@example.com', jobTitle: 'Frontend Developer', stage: 'Hired' },
    { id: 105, name: 'Fajar Nugraha', email: 'fajar@example.com', jobTitle: 'Product Manager', stage: 'Applied' }
];

// DUMMY AUTH CONFIG
const DUMMY_USER = { email: 'admin@talentstream.com', password: 'password123' };

// DOM ELEMENTS
const loginView = document.getElementById('login-view');
const appView = document.getElementById('app-view');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const btnLogout = document.getElementById('btn-logout');

// 1. DUMMY AUTH LOGIC
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;

    if (email === DUMMY_USER.email && pass === DUMMY_USER.password) {
        loginView.classList.remove('active');
        appView.classList.remove('layout-hidden');
        appView.classList.add('active');
        initApp();
    } else {
        loginError.textContent = 'Invalid email or password.';
    }
});

btnLogout.addEventListener('click', () => {
    appView.classList.remove('active');
    appView.classList.add('layout-hidden');
    loginView.classList.add('active');
    loginForm.reset();
    loginError.textContent = '';
});

// 2. NAVIGATION SPA LOGIC
const navItems = document.querySelectorAll('.nav-item');
const tabContents = document.querySelectorAll('.tab-content');
const pageTitle = document.getElementById('page-title');

navItems.forEach(item => {
    item.addEventListener('click', () => {
        navItems.forEach(nav => nav.classList.remove('active'));
        tabContents.forEach(tab => tab.classList.remove('active'));

        item.classList.add('active');
        const target = item.getAttribute('data-target');
        document.getElementById(target).classList.add('active');
        
        pageTitle.textContent = item.textContent.trim();
    });
});

// 3. RENDER CORE FUNCTIONS
function initApp() {
    updateStats();
    renderJobs(jobs);
    renderPipeline();
    lucide.createIcons(); // Re-render icons
}

function updateStats() {
    document.getElementById('stat-jobs').textContent = jobs.length;
    document.getElementById('stat-candidates').textContent = candidates.length;
    document.getElementById('stat-applications').textContent = candidates.length;
}

function renderJobs(jobData) {
    const tableBody = document.getElementById('job-table-body');
    tableBody.innerHTML = '';

    jobData.forEach(job => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="font-weight: 500;">${job.title}</td>
            <td>${job.dept}</td>
            <td><span class="status-badge ${job.status.toLowerCase()}">${job.status}</span></td>
            <td><strong>${job.applicants}</strong> Applicants</td>
        `;
        tableBody.appendChild(tr);
    });
}

function renderPipeline() {
    const stages = ['Applied', 'Interview', 'Hired'];
    
    stages.forEach(stage => {
        const container = document.getElementById(`list-${stage.toLowerCase()}`);
        const countBadge = document.getElementById(`count-${stage.toLowerCase()}`);
        container.innerHTML = '';
        
        const filtered = candidates.filter(c => c.stage === stage);
        countBadge.textContent = filtered.length;

        filtered.forEach(candidate => {
            const card = document.createElement('div');
            card.className = 'candidate-card';
            card.innerHTML = `
                <h4>${candidate.name}</h4>
                <p>${candidate.jobTitle}</p>
                <p style="color: #94a3b8; font-size: 10px; margin-top:4px;">${candidate.email}</p>
            `;
            container.appendChild(card);
        });
    });
}

// 4. SEARCH & FILTER JOBS
const searchInput = document.getElementById('search-job');
const statusFilter = document.getElementById('filter-job-status');

function filterJobs() {
    const query = searchInput.value.toLowerCase();
    const status = statusFilter.value;

    const filtered = jobs.filter(job => {
        const matchesSearch = job.title.toLowerCase().includes(query);
        const matchesStatus = status === 'all' || job.status === status;
        return matchesSearch && matchesStatus;
    });

    renderJobs(filtered);
}

searchInput.addEventListener('input', filterJobs);
statusFilter.addEventListener('change', filterJobs);

// 5. MODAL MANAGEMENT (ADD NEW JOB)
const modal = document.getElementById('job-modal');
const btnOpenModal = document.getElementById('btn-open-modal');
const btnCloseModal = document.querySelector('.close-modal');
const jobForm = document.getElementById('job-form');

btnOpenModal.addEventListener('click', () => modal.classList.add('active'));
btnCloseModal.addEventListener('click', () => modal.classList.remove('active'));

jobForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const newJob = {
        id: jobs.length + 1,
        title: document.getElementById('modal-job-title').value,
        dept: document.getElementById('modal-job-dept').value,
        status: document.getElementById('modal-job-status').value,
        applicants: 0
    };

    jobs.push(newJob);
    modal.classList.remove('active');
    jobForm.reset();
    
    initApp(); // Refresh semua UI data
});

// Initialize Lucide Icons on first load
lucide.createIcons();
